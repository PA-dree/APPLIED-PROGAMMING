using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class Resource
    {
        [Key]
        public Guid ResourceId { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(100)]
        public string ResourceType { get; set; } = string.Empty; // Food, Clothing, Medical, etc.

        [Required]
        public int Quantity { get; set; }

        [StringLength(20)]
        public string? Unit { get; set; } // kg, pieces, boxes, etc.

        [StringLength(500)]
        public string? Description { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal? EstimatedValue { get; set; }

        [StringLength(200)]
        public string? StorageLocation { get; set; }

        [StringLength(50)]
        public string Status { get; set; } = "Available"; // Available, Allocated, Distributed

        public DateTime DateAdded { get; set; } = DateTime.UtcNow;

        public DateTime? ExpiryDate { get; set; }

        // Foreign Key
        public Guid? DonationId { get; set; }

        // Navigation properties
        [ForeignKey("DonationId")]
        public virtual Donation? Donation { get; set; }
    }
}
