using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class VolunteerTask
    {
        [Required]
        public Guid VolunteerId { get; set; }

        [Required]
        public Guid TaskId { get; set; }

        public DateTime DateAssigned { get; set; } = DateTime.UtcNow;

        public DateTime? DateCompleted { get; set; }

        [StringLength(50)]
        public string Status { get; set; } = "Assigned"; // Assigned, In Progress, Completed, Cancelled

        [Column(TypeName = "decimal(5,2)")]
        public decimal? HoursWorked { get; set; }

        [Range(1, 5)]
        public int? Rating { get; set; }

        [StringLength(500)]
        public string? Comments { get; set; }

        // Navigation properties
        [ForeignKey("VolunteerId")]
        public virtual Volunteer Volunteer { get; set; } = null!;

        [ForeignKey("TaskId")]
        public virtual TaskItem Task { get; set; } = null!;
    }
}
