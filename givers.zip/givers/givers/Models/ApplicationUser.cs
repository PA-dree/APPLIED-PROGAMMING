using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace givers.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [StringLength(100)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string LastName { get; set; } = string.Empty;

        public string FullName => $"{FirstName} {LastName}";

        [StringLength(50)]
        public string? Role { get; set; }

        [StringLength(500)]
        public string? ProfileImageUrl { get; set; }

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public DateTime? LastLoginDate { get; set; }

        public bool IsActive { get; set; } = true;

        // Navigation properties
        public virtual ICollection<Incident> ReportedIncidents { get; set; } = new List<Incident>();
        public virtual ICollection<Donation> Donations { get; set; } = new List<Donation>();
        public virtual Volunteer? VolunteerProfile { get; set; }
    }
}
