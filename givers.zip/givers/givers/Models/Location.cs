using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class Location
    {
        [Key]
        public Guid LocationId { get; set; } = Guid.NewGuid();

        [StringLength(200)]
        public string? StreetAddress { get; set; }

        [Required]
        [StringLength(100)]
        public string City { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Province { get; set; } = string.Empty;

        [StringLength(10)]
        public string? PostalCode { get; set; }

        [StringLength(100)]
        public string Country { get; set; } = "South Africa";

        [Column(TypeName = "decimal(10,8)")]
        public decimal? Latitude { get; set; }

        [Column(TypeName = "decimal(11,8)")]
        public decimal? Longitude { get; set; }

        [StringLength(50)]
        public string? LocationType { get; set; } // Distribution Center, Emergency Shelter, etc.

        public DateTime DateAdded { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public virtual ICollection<Incident> Incidents { get; set; } = new List<Incident>();
    }
}
