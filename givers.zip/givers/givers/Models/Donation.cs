using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class Donation
    {
        [Key]
        public Guid DonationId { get; set; } = Guid.NewGuid();

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Amount { get; set; }

        [StringLength(3)]
        public string Currency { get; set; } = "ZAR";

        [Required]
        [StringLength(50)]
        public string DonationType { get; set; } = string.Empty; // Monetary, Material, Service

        [StringLength(50)]
        public string? PaymentMethod { get; set; }

        [StringLength(100)]
        public string? TransactionReference { get; set; }

        [StringLength(50)]
        public string? ReceiptNumber { get; set; }

        [StringLength(50)]
        public string Status { get; set; } = "Pending"; // Pending, Completed, Failed

        public bool IsAnonymous { get; set; } = false;

        public DateTime DateDonated { get; set; } = DateTime.UtcNow;

        public string? Notes { get; set; }

        // Foreign Key
        [Required]
        public string DonorId { get; set; } = string.Empty;

        // Navigation properties
        [ForeignKey("DonorId")]
        public virtual ApplicationUser Donor { get; set; } = null!;

        public virtual ICollection<Resource> Resources { get; set; } = new List<Resource>();
    }
}
