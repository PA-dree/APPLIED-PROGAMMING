using System.ComponentModel.DataAnnotations;
using givers.Models;

namespace givers.ViewModels
{
    // Incident ViewModels
    public class IncidentViewModel
    {
        public Guid IncidentId { get; set; }

        [Required]
        [Display(Name = "Incident Type")]
        public string IncidentType { get; set; } = string.Empty;

        [Required]
        [Range(1, 5)]
        [Display(Name = "Severity (1-5)")]
        public int Severity { get; set; }

        [Required]
        [Display(Name = "Description")]
        public string Description { get; set; } = string.Empty;

        [Range(1, 10)]
        [Display(Name = "Priority (1-10)")]
        public int Priority { get; set; }

        [Display(Name = "Estimated Affected People")]
        public int? EstimatedAffected { get; set; }

        public string Status { get; set; } = string.Empty;

        // Location properties
        [Display(Name = "Street Address")]
        public string? StreetAddress { get; set; }

        [Required]
        [Display(Name = "City")]
        public string City { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Province")]
        public string Province { get; set; } = string.Empty;

        [Display(Name = "Postal Code")]
        public string? PostalCode { get; set; }

        [Display(Name = "Latitude")]
        public decimal? Latitude { get; set; }

        [Display(Name = "Longitude")]
        public decimal? Longitude { get; set; }
    }

    // Donation ViewModels
    public class DonationViewModel
    {
        [Required]
        [Display(Name = "Donation Amount")]
        [DataType(DataType.Currency)]
        [Range(1, 1000000, ErrorMessage = "Please enter a valid amount")]
        public decimal Amount { get; set; }

        [Required]
        [Display(Name = "Donation Type")]
        public string DonationType { get; set; } = string.Empty;

        [Display(Name = "Payment Method")]
        public string? PaymentMethod { get; set; }

        [Display(Name = "Make this donation anonymous")]
        public bool IsAnonymous { get; set; }

        [Display(Name = "Resources (for material donations)")]
        public List<ResourceViewModel>? Resources { get; set; }
    }

    public class ResourceViewModel
    {
        [Required]
        [Display(Name = "Resource Type")]
        public string ResourceType { get; set; } = string.Empty;

        [Required]
        [Range(1, int.MaxValue)]
        [Display(Name = "Quantity")]
        public int Quantity { get; set; }

        [Display(Name = "Unit")]
        public string? Unit { get; set; }

        [Display(Name = "Description")]
        public string? Description { get; set; }

        [Display(Name = "Estimated Value")]
        [DataType(DataType.Currency)]
        public decimal? EstimatedValue { get; set; }

        [Display(Name = "Storage Location")]
        public string? StorageLocation { get; set; }
    }

    // Volunteer ViewModels
    public class VolunteerViewModel
    {
        [Display(Name = "Skills")]
        [Required(ErrorMessage = "Please list your skills")]
        public string Skills { get; set; } = string.Empty;

        [Display(Name = "Availability")]
        [Required(ErrorMessage = "Please specify your availability")]
        public string Availability { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Emergency Contact")]
        [Phone]
        public string EmergencyContact { get; set; } = string.Empty;

        [Display(Name = "Preferred Tasks")]
        public string? PreferredTasks { get; set; }
    }

    public class TaskAssignmentViewModel
    {
        public Guid TaskId { get; set; }
        public string TaskTitle { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string? RequiredSkills { get; set; }
        public decimal? EstimatedHours { get; set; }
        public int Priority { get; set; }
        public string IncidentType { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public DateTime? DateDue { get; set; }
    }

    // Dashboard ViewModel
    public class DashboardViewModel
    {
        public int TotalIncidents { get; set; }
        public int ActiveIncidents { get; set; }
        public decimal TotalDonations { get; set; }
        public int TotalVolunteers { get; set; }
        public List<Incident> RecentIncidents { get; set; } = new List<Incident>();
        public List<Donation> RecentDonations { get; set; } = new List<Donation>();
    }

    public class VolunteerDashboardViewModel
    {
        public Volunteer Volunteer { get; set; } = null!;
        public List<TaskItem> AvailableTasks { get; set; } = new List<TaskItem>();
        public List<VolunteerTask> AssignedTasks { get; set; } = new List<VolunteerTask>();
        public List<VolunteerTask> CompletedTasks { get; set; } = new List<VolunteerTask>();
        public decimal TotalHours { get; set; }
        public int TasksCompleted { get; set; }
    }

    // Error ViewModel
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
