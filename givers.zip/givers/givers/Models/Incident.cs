using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class Incident
    {
        [Key]
        public Guid IncidentId { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(50)]
        public string IncidentType { get; set; } = string.Empty;

        [Required]
        [Range(1, 5)]
        public int Severity { get; set; }

        [Required]
        public string Description { get; set; } = string.Empty;

        [Range(1, 10)]
        public int Priority { get; set; } = 1;

        public int? EstimatedAffected { get; set; }

        [StringLength(50)]
        public string Status { get; set; } = "Reported";

        public DateTime DateReported { get; set; } = DateTime.UtcNow;

        public DateTime? DateResolved { get; set; }

        // Foreign Keys
        [Required]
        public string ReporterId { get; set; } = string.Empty;

        [Required]
        public Guid LocationId { get; set; }

        // Navigation properties
        [ForeignKey("ReporterId")]
        public virtual ApplicationUser Reporter { get; set; } = null!;

        [ForeignKey("LocationId")]
        public virtual Location Location { get; set; } = null!;

        public virtual ICollection<TaskItem> Tasks { get; set; } = new List<TaskItem>();
    }
}
