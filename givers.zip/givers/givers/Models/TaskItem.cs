using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class TaskItem
    {
        [Key]
        public Guid TaskId { get; set; } = Guid.NewGuid();

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [StringLength(500)]
        public string? RequiredSkills { get; set; }

        [Column(TypeName = "decimal(5,2)")]
        public decimal? EstimatedHours { get; set; }

        [Range(1, 10)]
        public int Priority { get; set; } = 1;

        [StringLength(50)]
        public string Status { get; set; } = "Open"; // Open, In Progress, Completed, Cancelled

        public DateTime DateCreated { get; set; } = DateTime.UtcNow;

        public DateTime? DateDue { get; set; }

        public DateTime? DateCompleted { get; set; }

        public int MaxVolunteers { get; set; } = 1;

        // Foreign Key
        public Guid? IncidentId { get; set; }

        // Navigation properties
        [ForeignKey("IncidentId")]
        public virtual Incident? Incident { get; set; }

        public virtual ICollection<VolunteerTask> VolunteerTasks { get; set; } = new List<VolunteerTask>();
    }
}
