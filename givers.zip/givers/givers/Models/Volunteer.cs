using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace givers.Models
{
    public class Volunteer
    {
        [Key]
        public Guid VolunteerId { get; set; } = Guid.NewGuid();

        [Required]
        public string Skills { get; set; } = string.Empty;

        [Required]
        public string Availability { get; set; } = string.Empty;

        [StringLength(200)]
        public string? EmergencyContact { get; set; }

        public string? PreferredTasks { get; set; }

        [StringLength(50)]
        public string? BackgroundCheckStatus { get; set; } = "Pending";

        public DateTime DateJoined { get; set; } = DateTime.UtcNow;

        [Column(TypeName = "decimal(10,2)")]
        public decimal HoursContributed { get; set; } = 0;

        [Column(TypeName = "decimal(3,2)")]
        public decimal? Rating { get; set; }

        public bool IsActive { get; set; } = true;

        // Foreign Key
        [Required]
        public string UserId { get; set; } = string.Empty;

        // Navigation properties
        [ForeignKey("UserId")]
        public virtual ApplicationUser User { get; set; } = null!;

        public virtual ICollection<VolunteerTask> VolunteerTasks { get; set; } = new List<VolunteerTask>();
    }
}
