﻿using Microsoft.EntityFrameworkCore;
using givers.Data;
using givers.Models;
using System.Net.Mail;
using System.Net;

namespace givers.Services
{
    // ========== SERVICE INTERFACES ==========

    public interface IIncidentService
    {
        Task<IEnumerable<Incident>> GetAllIncidentsAsync();
        Task<Incident> GetIncidentByIdAsync(Guid id);
        Task<Incident> CreateIncidentAsync(Incident incident);
        Task UpdateIncidentAsync(Incident incident);
        Task DeleteIncidentAsync(Guid id);
        Task<IEnumerable<Incident>> GetIncidentsByStatusAsync(string status);
        Task<IEnumerable<Incident>> GetIncidentsByLocationAsync(string city, string province);
    }

    public interface IDonationService
    {
        Task<Donation> CreateDonationAsync(Donation donation);
        Task<IEnumerable<Donation>> GetDonationsByUserAsync(string userId);
        Task<decimal> GetTotalDonationsAsync();
        Task<string> ProcessPaymentAsync(Donation donation);
        Task<byte[]> GenerateReceiptPdfAsync(Guid donationId);
    }

    public interface IVolunteerService
    {
        Task<Volunteer> RegisterVolunteerAsync(Volunteer volunteer);
        Task<IEnumerable<TaskItem>> GetAvailableTasksAsync();
        Task AssignTaskToVolunteerAsync(Guid volunteerId, Guid taskId);
        Task CompleteTaskAsync(Guid volunteerId, Guid taskId, decimal hoursWorked);
        Task<IEnumerable<VolunteerTask>> GetVolunteerTasksAsync(Guid volunteerId);
        Task UpdateVolunteerHoursAsync(Guid volunteerId, decimal hours);
    }

    public interface IEmailService
    {
        Task SendEmailAsync(string to, string subject, string body);
        Task SendConfirmationEmailAsync(string email, string confirmationLink);
        Task SendDonationReceiptAsync(string email, Donation donation);
        Task SendVolunteerWelcomeEmailAsync(string email, string volunteerName);
    }

    public interface ILocationService
    {
        Task<Location> CreateLocationAsync(Location location);
        Task<Location> GetLocationByIdAsync(Guid id);
        Task<IEnumerable<Location>> GetLocationsByTypeAsync(string locationType);
        Task<(decimal latitude, decimal longitude)> GeocodeAddressAsync(string address);
    }

    // ========== SERVICE IMPLEMENTATIONS ==========

    public class IncidentService : IIncidentService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<IncidentService> _logger;

        public IncidentService(ApplicationDbContext context, ILogger<IncidentService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<Incident>> GetAllIncidentsAsync()
        {
            return await _context.Incidents
                .Include(i => i.Location)
                .Include(i => i.Reporter)
                .OrderByDescending(i => i.DateReported)
                .ToListAsync();
        }

        public async Task<Incident> GetIncidentByIdAsync(Guid id)
        {
            return await _context.Incidents
                .Include(i => i.Location)
                .Include(i => i.Reporter)
                .Include(i => i.Tasks)
                .FirstOrDefaultAsync(i => i.IncidentId == id);
        }

        public async Task<Incident> CreateIncidentAsync(Incident incident)
        {
            _context.Incidents.Add(incident);
            await _context.SaveChangesAsync();
            _logger.LogInformation($"Incident created with ID: {incident.IncidentId}");
            return incident;
        }

        public async Task UpdateIncidentAsync(Incident incident)
        {
            _context.Update(incident);
            await _context.SaveChangesAsync();
            _logger.LogInformation($"Incident updated: {incident.IncidentId}");
        }

        public async Task DeleteIncidentAsync(Guid id)
        {
            var incident = await _context.Incidents.FindAsync(id);
            if (incident != null)
            {
                _context.Incidents.Remove(incident);
                await _context.SaveChangesAsync();
                _logger.LogInformation($"Incident deleted: {id}");
            }
        }

        public async Task<IEnumerable<Incident>> GetIncidentsByStatusAsync(string status)
        {
            return await _context.Incidents
                .Include(i => i.Location)
                .Where(i => i.Status == status)
                .OrderByDescending(i => i.Priority)
                .ToListAsync();
        }

        public async Task<IEnumerable<Incident>> GetIncidentsByLocationAsync(string city, string province)
        {
            return await _context.Incidents
                .Include(i => i.Location)
                .Where(i => i.Location.City == city && i.Location.Province == province)
                .OrderByDescending(i => i.DateReported)
                .ToListAsync();
        }
    }

    public class DonationService : IDonationService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<DonationService> _logger;
        private readonly IEmailService _emailService;

        public DonationService(
            ApplicationDbContext context,
            ILogger<DonationService> logger,
            IEmailService emailService)
        {
            _context = context;
            _logger = logger;
            _emailService = emailService;
        }

        public async Task<Donation> CreateDonationAsync(Donation donation)
        {
            // Generate unique references
            donation.TransactionReference = GenerateTransactionReference();
            donation.ReceiptNumber = GenerateReceiptNumber();

            _context.Donations.Add(donation);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"Donation created: {donation.DonationId}");

            // Send receipt email if not anonymous
            if (!donation.IsAnonymous && donation.Donor != null)
            {
                await _emailService.SendDonationReceiptAsync(donation.Donor.Email, donation);
            }

            return donation;
        }

        public async Task<IEnumerable<Donation>> GetDonationsByUserAsync(string userId)
        {
            return await _context.Donations
                .Include(d => d.Resources)
                .Where(d => d.DonorId == userId)
                .OrderByDescending(d => d.DateDonated)
                .ToListAsync();
        }

        public async Task<decimal> GetTotalDonationsAsync()
        {
            return await _context.Donations
                .Where(d => d.Status == "Completed")
                .SumAsync(d => d.Amount);
        }

        public async Task<string> ProcessPaymentAsync(Donation donation)
        {
            try
            {
                // TODO: Integrate with actual payment gateway (Stripe, PayPal, etc.)
                // This is a placeholder for payment processing logic

                await Task.Delay(1000); // Simulate API call

                // Update donation status
                donation.Status = "Completed";
                _context.Update(donation);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Payment processed for donation: {donation.DonationId}");
                return "Success";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Payment processing failed for donation: {donation.DonationId}");
                return "Failed";
            }
        }

        public async Task<byte[]> GenerateReceiptPdfAsync(Guid donationId)
        {
            var donation = await _context.Donations
                .Include(d => d.Donor)
                .FirstOrDefaultAsync(d => d.DonationId == donationId);

            if (donation == null)
                return null;

            // TODO: Implement PDF generation using a library like iTextSharp or QuestPDF
            // This is a placeholder
            var receiptContent = $@"
                GIFT OF THE GIVERS FOUNDATION
                DONATION RECEIPT
                
                Receipt Number: {donation.ReceiptNumber}
                Date: {donation.DateDonated:yyyy-MM-dd}
                
                Donor: {(donation.IsAnonymous ? "Anonymous" : donation.Donor?.FullName)}
                Amount: R {donation.Amount:N2}
                Type: {donation.DonationType}
                
                Thank you for your generous donation!
            ";

            return System.Text.Encoding.UTF8.GetBytes(receiptContent);
        }

        private string GenerateTransactionReference()
        {
            return $"TXN{DateTime.Now:yyyyMMddHHmmss}{Guid.NewGuid().ToString().Substring(0, 4).ToUpper()}";
        }

        private string GenerateReceiptNumber()
        {
            return $"RCP{DateTime.Now:yyyyMMdd}{new Random().Next(10000, 99999)}";
        }
    }

    public class VolunteerService : IVolunteerService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<VolunteerService> _logger;
        private readonly IEmailService _emailService;

        public VolunteerService(
            ApplicationDbContext context,
            ILogger<VolunteerService> logger,
            IEmailService emailService)
        {
            _context = context;
            _logger = logger;
            _emailService = emailService;
        }

        public async Task<Volunteer> RegisterVolunteerAsync(Volunteer volunteer)
        {
            _context.Volunteers.Add(volunteer);
            await _context.SaveChangesAsync();

            _logger.LogInformation($"New volunteer registered: {volunteer.VolunteerId}");

            // Send welcome email
            var user = await _context.Users.FindAsync(volunteer.UserId);
            if (user != null)
            {
                await _emailService.SendVolunteerWelcomeEmailAsync(user.Email, user.FullName);
            }

            return volunteer;
        }

        public async Task<IEnumerable<TaskItem>> GetAvailableTasksAsync()
        {
            return await _context.Tasks
                .Include(t => t.Incident)
                    .ThenInclude(i => i.Location)
                .Where(t => t.Status == "Open")
                .OrderBy(t => t.Priority)
                .ThenBy(t => t.DateDue)
                .ToListAsync();
        }

        public async Task AssignTaskToVolunteerAsync(Guid volunteerId, Guid taskId)
        {
            var volunteerTask = new VolunteerTask
            {
                VolunteerId = volunteerId,
                TaskId = taskId,
                DateAssigned = DateTime.Now,
                Status = "Assigned"
            };

            _context.VolunteerTasks.Add(volunteerTask);

            // Update task status if max volunteers reached
            var task = await _context.Tasks.FindAsync(taskId);
            var assignedCount = await _context.VolunteerTasks
                .CountAsync(vt => vt.TaskId == taskId && vt.Status == "Assigned");

            if (assignedCount >= task.MaxVolunteers)
            {
                task.Status = "In Progress";
                _context.Update(task);
            }

            await _context.SaveChangesAsync();
            _logger.LogInformation($"Task {taskId} assigned to volunteer {volunteerId}");
        }

        public async Task CompleteTaskAsync(Guid volunteerId, Guid taskId, decimal hoursWorked)
        {
            var volunteerTask = await _context.VolunteerTasks
                .FirstOrDefaultAsync(vt => vt.VolunteerId == volunteerId && vt.TaskId == taskId);

            if (volunteerTask != null)
            {
                volunteerTask.Status = "Completed";
                volunteerTask.DateCompleted = DateTime.Now;
                volunteerTask.HoursWorked = hoursWorked;

                _context.Update(volunteerTask);

                // Update volunteer's total hours
                await UpdateVolunteerHoursAsync(volunteerId, hoursWorked);

                await _context.SaveChangesAsync();
                _logger.LogInformation($"Task {taskId} completed by volunteer {volunteerId}");
            }
        }

        public async Task<IEnumerable<VolunteerTask>> GetVolunteerTasksAsync(Guid volunteerId)
        {
            return await _context.VolunteerTasks
                .Include(vt => vt.Task)
                    .ThenInclude(t => t.Incident)
                .Where(vt => vt.VolunteerId == volunteerId)
                .OrderByDescending(vt => vt.DateAssigned)
                .ToListAsync();
        }

        public async Task UpdateVolunteerHoursAsync(Guid volunteerId, decimal hours)
        {
            var volunteer = await _context.Volunteers.FindAsync(volunteerId);
            if (volunteer != null)
            {
                volunteer.HoursContributed += hours;
                _context.Update(volunteer);
                await _context.SaveChangesAsync();
            }
        }
    }

    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IConfiguration configuration, ILogger<EmailService> logger)
        {
            _configuration = configuration;
            _logger = logger;
        }

        public async Task SendEmailAsync(string to, string subject, string body)
        {
            try
            {
                // Get SMTP settings from configuration
                var smtpHost = _configuration["EmailSettings:SmtpHost"] ?? "smtp.gmail.com";
                var smtpPort = int.Parse(_configuration["EmailSettings:SmtpPort"] ?? "587");
                var smtpUsername = _configuration["EmailSettings:Username"];
                var smtpPassword = _configuration["EmailSettings:Password"];
                var fromEmail = _configuration["EmailSettings:FromEmail"] ?? "noreply@giftofthegivers.org";
                var fromName = _configuration["EmailSettings:FromName"] ?? "Gift of the Givers";

                using var client = new SmtpClient(smtpHost, smtpPort)
                {
                    EnableSsl = true,
                    Credentials = new NetworkCredential(smtpUsername, smtpPassword)
                };

                var message = new MailMessage
                {
                    From = new MailAddress(fromEmail, fromName),
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                };
                message.To.Add(to);

                await client.SendMailAsync(message);
                _logger.LogInformation($"Email sent to {to}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Failed to send email to {to}");
                // Don't throw - email failure shouldn't break the application
            }
        }

        public async Task SendConfirmationEmailAsync(string email, string confirmationLink)
        {
            var subject = "Confirm your email - Gift of the Givers";
            var body = $@"
                <h2>Welcome to Gift of the Givers Foundation!</h2>
                <p>Please confirm your email address by clicking the link below:</p>
                <p><a href='{confirmationLink}'>Confirm Email</a></p>
                <p>If you didn't create an account, please ignore this email.</p>
            ";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendDonationReceiptAsync(string email, Donation donation)
        {
            var subject = "Donation Receipt - Gift of the Givers";
            var body = $@"
                <h2>Thank You for Your Donation!</h2>
                <p>Receipt Number: {donation.ReceiptNumber}</p>
                <p>Amount: R {donation.Amount:N2}</p>
                <p>Date: {donation.DateDonated:yyyy-MM-dd}</p>
                <p>Your generosity helps us make a difference in communities affected by disasters.</p>
                <p>This receipt serves as official documentation for tax purposes.</p>
            ";

            await SendEmailAsync(email, subject, body);
        }

        public async Task SendVolunteerWelcomeEmailAsync(string email, string volunteerName)
        {
            var subject = "Welcome to our Volunteer Team - Gift of the Givers";
            var body = $@"
                <h2>Welcome {volunteerName}!</h2>
                <p>Thank you for joining our volunteer team at Gift of the Givers Foundation.</p>
                <p>Your dedication to helping others makes a real difference in our communities.</p>
                <p>You can now:</p>
                <ul>
                    <li>Browse and sign up for volunteer tasks</li>
                    <li>Track your volunteer hours</li>
                    <li>Connect with other volunteers</li>
                </ul>
                <p>We look forward to working with you!</p>
            ";

            await SendEmailAsync(email, subject, body);
        }
    }

    public class LocationService : ILocationService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<LocationService> _logger;

        public LocationService(ApplicationDbContext context, ILogger<LocationService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<Location> CreateLocationAsync(Location location)
        {
            _context.Locations.Add(location);
            await _context.SaveChangesAsync();
            _logger.LogInformation($"Location created: {location.LocationId}");
            return location;
        }

        public async Task<Location> GetLocationByIdAsync(Guid id)
        {
            return await _context.Locations.FindAsync(id);
        }

        public async Task<IEnumerable<Location>> GetLocationsByTypeAsync(string locationType)
        {
            return await _context.Locations
                .Where(l => l.LocationType == locationType)
                .OrderBy(l => l.Province)
                .ThenBy(l => l.City)
                .ToListAsync();
        }

        public async Task<(decimal latitude, decimal longitude)> GeocodeAddressAsync(string address)
        {
            // TODO: Integrate with a geocoding service like Google Maps or Bing Maps
            // This is a placeholder that returns coordinates for Johannesburg
            await Task.Delay(100); // Simulate API call

            // Default coordinates (Johannesburg, South Africa)
            return (-26.2041m, 28.0473m);
        }
    }
}