-- ===============================================================
-- Disaster Alleviation Foundation Database Schema
-- Generated for SQL Server Management Studio (SSMS)
-- ===============================================================

USE [DisasterAlleviationDB]
GO

-- ===============================================================
-- 1. ASP.NET Identity Tables (Required for Authentication)
-- ===============================================================

-- AspNetRoles Table
CREATE TABLE [dbo].[AspNetRoles] (
    [Id] NVARCHAR(450) NOT NULL PRIMARY KEY,
    [Name] NVARCHAR(256) NULL,
    [NormalizedName] NVARCHAR(256) NULL,
    [ConcurrencyStamp] NVARCHAR(MAX) NULL
);
GO

CREATE UNIQUE INDEX [RoleNameIndex] ON [AspNetRoles] ([NormalizedName]) WHERE [NormalizedName] IS NOT NULL;
GO

-- AspNetUsers Table (Extended with custom properties)
CREATE TABLE [dbo].[AspNetUsers] (
    [Id] NVARCHAR(450) NOT NULL PRIMARY KEY,
    [UserName] NVARCHAR(256) NULL,
    [NormalizedUserName] NVARCHAR(256) NULL,
    [Email] NVARCHAR(256) NULL,
    [NormalizedEmail] NVARCHAR(256) NULL,
    [EmailConfirmed] BIT NOT NULL,
    [PasswordHash] NVARCHAR(MAX) NULL,
    [SecurityStamp] NVARCHAR(MAX) NULL,
    [ConcurrencyStamp] NVARCHAR(MAX) NULL,
    [PhoneNumber] NVARCHAR(MAX) NULL,
    [PhoneNumberConfirmed] BIT NOT NULL,
    [TwoFactorEnabled] BIT NOT NULL,
    [LockoutEnd] DATETIMEOFFSET(7) NULL,
    [LockoutEnabled] BIT NOT NULL,
    [AccessFailedCount] INT NOT NULL,
    -- Custom Properties for Disaster Alleviation App
    [FirstName] NVARCHAR(100) NOT NULL,
    [LastName] NVARCHAR(100) NOT NULL,
    [Role] NVARCHAR(50) NULL,
    [ProfileImageUrl] NVARCHAR(500) NULL,
    [DateCreated] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [LastLoginDate] DATETIME2(7) NULL,
    [IsActive] BIT NOT NULL DEFAULT 1
);
GO

CREATE UNIQUE INDEX [UserNameIndex] ON [AspNetUsers] ([NormalizedUserName]) WHERE [NormalizedUserName] IS NOT NULL;
GO

CREATE INDEX [EmailIndex] ON [AspNetUsers] ([NormalizedEmail]);
GO

CREATE UNIQUE INDEX [IX_AspNetUsers_Email] ON [AspNetUsers] ([Email]) WHERE [Email] IS NOT NULL;
GO

-- AspNetUserRoles Table
CREATE TABLE [dbo].[AspNetUserRoles] (
    [UserId] NVARCHAR(450) NOT NULL,
    [RoleId] NVARCHAR(450) NOT NULL,
    PRIMARY KEY ([UserId], [RoleId]),
    FOREIGN KEY ([RoleId]) REFERENCES [AspNetRoles] ([Id]) ON DELETE CASCADE,
    FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

CREATE INDEX [IX_AspNetUserRoles_RoleId] ON [AspNetUserRoles] ([RoleId]);
GO

-- AspNetUserClaims Table
CREATE TABLE [dbo].[AspNetUserClaims] (
    [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [UserId] NVARCHAR(450) NOT NULL,
    [ClaimType] NVARCHAR(MAX) NULL,
    [ClaimValue] NVARCHAR(MAX) NULL,
    FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

CREATE INDEX [IX_AspNetUserClaims_UserId] ON [AspNetUserClaims] ([UserId]);
GO

-- AspNetUserLogins Table
CREATE TABLE [dbo].[AspNetUserLogins] (
    [LoginProvider] NVARCHAR(450) NOT NULL,
    [ProviderKey] NVARCHAR(450) NOT NULL,
    [ProviderDisplayName] NVARCHAR(MAX) NULL,
    [UserId] NVARCHAR(450) NOT NULL,
    PRIMARY KEY ([LoginProvider], [ProviderKey]),
    FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

CREATE INDEX [IX_AspNetUserLogins_UserId] ON [AspNetUserLogins] ([UserId]);
GO

-- AspNetUserTokens Table
CREATE TABLE [dbo].[AspNetUserTokens] (
    [UserId] NVARCHAR(450) NOT NULL,
    [LoginProvider] NVARCHAR(450) NOT NULL,
    [Name] NVARCHAR(450) NOT NULL,
    [Value] NVARCHAR(MAX) NULL,
    PRIMARY KEY ([UserId], [LoginProvider], [Name]),
    FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

-- AspNetRoleClaims Table
CREATE TABLE [dbo].[AspNetRoleClaims] (
    [Id] INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    [RoleId] NVARCHAR(450) NOT NULL,
    [ClaimType] NVARCHAR(MAX) NULL,
    [ClaimValue] NVARCHAR(MAX) NULL,
    FOREIGN KEY ([RoleId]) REFERENCES [AspNetRoles] ([Id]) ON DELETE CASCADE
);
GO

CREATE INDEX [IX_AspNetRoleClaims_RoleId] ON [AspNetRoleClaims] ([RoleId]);
GO

-- ===============================================================
-- 2. Application-Specific Tables
-- ===============================================================

-- Locations Table
CREATE TABLE [dbo].[Locations] (
    [LocationId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [StreetAddress] NVARCHAR(200) NULL,
    [City] NVARCHAR(100) NOT NULL,
    [Province] NVARCHAR(100) NOT NULL,
    [PostalCode] NVARCHAR(10) NULL,
    [Country] NVARCHAR(100) NOT NULL DEFAULT 'South Africa',
    [Latitude] DECIMAL(10,8) NULL,
    [Longitude] DECIMAL(11,8) NULL,
    [LocationType] NVARCHAR(50) NULL DEFAULT 'General',
    [DateAdded] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE()
);
GO

-- Incidents Table
CREATE TABLE [dbo].[Incidents] (
    [IncidentId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [IncidentType] NVARCHAR(50) NOT NULL,
    [Severity] INT NOT NULL,
    [Priority] INT NOT NULL,
    [Description] NVARCHAR(MAX) NOT NULL,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Reported',
    [EstimatedAffected] INT NULL,
    [DateReported] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [DateResolved] DATETIME2(7) NULL,
    [ReporterId] NVARCHAR(450) NOT NULL,
    [LocationId] UNIQUEIDENTIFIER NOT NULL,
    [ResolutionNotes] NVARCHAR(MAX) NULL,
    FOREIGN KEY ([ReporterId]) REFERENCES [AspNetUsers] ([Id]),
    FOREIGN KEY ([LocationId]) REFERENCES [Locations] ([LocationId])
);
GO

-- Add check constraints for Incidents
ALTER TABLE [Incidents] ADD CONSTRAINT [CK_Incident_Severity] CHECK ([Severity] BETWEEN 1 AND 5);
GO

ALTER TABLE [Incidents] ADD CONSTRAINT [CK_Incident_Priority] CHECK ([Priority] BETWEEN 1 AND 10);
GO

CREATE INDEX [IX_Incidents_ReporterId] ON [Incidents] ([ReporterId]);
GO

CREATE INDEX [IX_Incidents_LocationId] ON [Incidents] ([LocationId]);
GO

CREATE INDEX [IX_Incidents_Status] ON [Incidents] ([Status]);
GO

CREATE INDEX [IX_Incidents_DateReported] ON [Incidents] ([DateReported]);
GO

-- Donations Table
CREATE TABLE [dbo].[Donations] (
    [DonationId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Amount] DECIMAL(10,2) NOT NULL,
    [DonationType] NVARCHAR(50) NOT NULL,
    [PaymentMethod] NVARCHAR(50) NULL,
    [TransactionReference] NVARCHAR(100) NULL,
    [ReceiptNumber] NVARCHAR(50) NULL,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    [IsAnonymous] BIT NOT NULL DEFAULT 0,
    [DateDonated] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [DateProcessed] DATETIME2(7) NULL,
    [DonorId] NVARCHAR(450) NOT NULL,
    [Notes] NVARCHAR(500) NULL,
    FOREIGN KEY ([DonorId]) REFERENCES [AspNetUsers] ([Id])
);
GO

-- Add check constraint for Donations
ALTER TABLE [Donations] ADD CONSTRAINT [CK_Donation_Type] CHECK ([DonationType] IN ('Monetary','Material','Service'));
GO

CREATE UNIQUE INDEX [IX_Donations_TransactionReference] ON [Donations] ([TransactionReference]) WHERE [TransactionReference] IS NOT NULL;
GO

CREATE UNIQUE INDEX [IX_Donations_ReceiptNumber] ON [Donations] ([ReceiptNumber]) WHERE [ReceiptNumber] IS NOT NULL;
GO

CREATE INDEX [IX_Donations_DonorId] ON [Donations] ([DonorId]);
GO

CREATE INDEX [IX_Donations_Status] ON [Donations] ([Status]);
GO

CREATE INDEX [IX_Donations_DateDonated] ON [Donations] ([DateDonated]);
GO

-- Resources Table
CREATE TABLE [dbo].[Resources] (
    [ResourceId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [ResourceType] NVARCHAR(100) NOT NULL,
    [Quantity] INT NOT NULL,
    [Unit] NVARCHAR(50) NULL,
    [Description] NVARCHAR(500) NULL,
    [EstimatedValue] DECIMAL(10,2) NULL,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Available',
    [StorageLocation] NVARCHAR(200) NULL,
    [DateAdded] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [DateDistributed] DATETIME2(7) NULL,
    [DonationId] UNIQUEIDENTIFIER NULL,
    FOREIGN KEY ([DonationId]) REFERENCES [Donations] ([DonationId]) ON DELETE SET NULL
);
GO

-- Add check constraint for Resources
ALTER TABLE [Resources] ADD CONSTRAINT [CK_Resource_Quantity] CHECK ([Quantity] > 0);
GO

CREATE INDEX [IX_Resources_DonationId] ON [Resources] ([DonationId]);
GO

CREATE INDEX [IX_Resources_ResourceType] ON [Resources] ([ResourceType]);
GO

CREATE INDEX [IX_Resources_Status] ON [Resources] ([Status]);
GO

-- Volunteers Table
CREATE TABLE [dbo].[Volunteers] (
    [VolunteerId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Skills] NVARCHAR(500) NOT NULL,
    [Availability] NVARCHAR(200) NOT NULL,
    [EmergencyContact] NVARCHAR(100) NOT NULL,
    [PreferredTasks] NVARCHAR(500) NULL,
    [Rating] DECIMAL(2,1) NULL DEFAULT 0.0,
    [TotalHours] DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    [TasksCompleted] INT NOT NULL DEFAULT 0,
    [IsActive] BIT NOT NULL DEFAULT 1,
    [DateRegistered] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [UserId] NVARCHAR(450) NOT NULL,
    FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
);
GO

-- Add check constraint for Volunteers
ALTER TABLE [Volunteers] ADD CONSTRAINT [CK_Volunteer_Rating] CHECK ([Rating] BETWEEN 0 AND 5);
GO

CREATE UNIQUE INDEX [IX_Volunteers_UserId] ON [Volunteers] ([UserId]);
GO

CREATE INDEX [IX_Volunteers_IsActive] ON [Volunteers] ([IsActive]);
GO

-- Tasks Table (TaskItem entity)
CREATE TABLE [dbo].[Tasks] (
    [TaskId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Title] NVARCHAR(200) NOT NULL,
    [Description] NVARCHAR(MAX) NOT NULL,
    [RequiredSkills] NVARCHAR(500) NULL,
    [EstimatedHours] DECIMAL(5,2) NULL,
    [Priority] INT NOT NULL DEFAULT 1,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Open',
    [MaxVolunteers] INT NOT NULL DEFAULT 1,
    [DateCreated] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [DateDue] DATETIME2(7) NULL,
    [DateCompleted] DATETIME2(7) NULL,
    [IncidentId] UNIQUEIDENTIFIER NULL,
    [CompletionNotes] NVARCHAR(MAX) NULL,
    FOREIGN KEY ([IncidentId]) REFERENCES [Incidents] ([IncidentId]) ON DELETE SET NULL
);
GO

-- Add check constraint for Tasks
ALTER TABLE [Tasks] ADD CONSTRAINT [CK_Task_Priority] CHECK ([Priority] BETWEEN 1 AND 10);
GO

CREATE INDEX [IX_Tasks_IncidentId] ON [Tasks] ([IncidentId]);
GO

CREATE INDEX [IX_Tasks_Status] ON [Tasks] ([Status]);
GO

CREATE INDEX [IX_Tasks_DateCreated] ON [Tasks] ([DateCreated]);
GO

-- VolunteerTasks Table (Many-to-Many relationship)
CREATE TABLE [dbo].[VolunteerTasks] (
    [VolunteerTaskId] UNIQUEIDENTIFIER NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [VolunteerId] UNIQUEIDENTIFIER NOT NULL,
    [TaskId] UNIQUEIDENTIFIER NOT NULL,
    [DateAssigned] DATETIME2(7) NOT NULL DEFAULT GETUTCDATE(),
    [DateStarted] DATETIME2(7) NULL,
    [DateCompleted] DATETIME2(7) NULL,
    [HoursWorked] DECIMAL(5,2) NULL DEFAULT 0.00,
    [Status] NVARCHAR(50) NOT NULL DEFAULT 'Assigned',
    [Rating] INT NULL,
    [Feedback] NVARCHAR(500) NULL,
    [Notes] NVARCHAR(500) NULL,
    FOREIGN KEY ([VolunteerId]) REFERENCES [Volunteers] ([VolunteerId]),
    FOREIGN KEY ([TaskId]) REFERENCES [Tasks] ([TaskId])
);
GO

-- Add check constraint for VolunteerTasks
ALTER TABLE [VolunteerTasks] ADD CONSTRAINT [CK_VolunteerTask_Rating] CHECK ([Rating] BETWEEN 1 AND 5);
GO

CREATE INDEX [IX_VolunteerTasks_VolunteerId] ON [VolunteerTasks] ([VolunteerId]);
GO

CREATE INDEX [IX_VolunteerTasks_TaskId] ON [VolunteerTasks] ([TaskId]);
GO

CREATE INDEX [IX_VolunteerTasks_Status] ON [VolunteerTasks] ([Status]);
GO

-- ===============================================================
-- 3. Entity Framework Migrations History Table
-- ===============================================================

CREATE TABLE [dbo].[__EFMigrationsHistory] (
    [MigrationId] NVARCHAR(150) NOT NULL PRIMARY KEY,
    [ProductVersion] NVARCHAR(32) NOT NULL
);
GO

-- ===============================================================
-- 4. Insert Initial Data (Roles and Sample Locations)
-- ===============================================================

-- Insert default roles
INSERT INTO [AspNetRoles] ([Id], [Name], [NormalizedName], [ConcurrencyStamp])
VALUES 
    (NEWID(), 'Admin', 'ADMIN', NEWID()),
    (NEWID(), 'Volunteer', 'VOLUNTEER', NEWID()),
    (NEWID(), 'Donor', 'DONOR', NEWID()),
    (NEWID(), 'Reporter', 'REPORTER', NEWID());
GO

-- Insert sample locations (Major South African cities)
INSERT INTO [Locations] ([LocationId], [City], [Province], [Country], [Latitude], [Longitude], [LocationType])
VALUES 
    (NEWID(), 'Cape Town', 'Western Cape', 'South Africa', -33.9249, 18.4241, 'Emergency Center'),
    (NEWID(), 'Johannesburg', 'Gauteng', 'South Africa', -26.2041, 28.0473, 'Emergency Center'),
    (NEWID(), 'Durban', 'KwaZulu-Natal', 'South Africa', -29.8587, 31.0218, 'Emergency Center');
GO

-- ===============================================================
-- 5. Useful Views for Reporting
-- ===============================================================

-- View: Active Incidents with Location Details
CREATE VIEW [dbo].[vw_ActiveIncidents] AS
SELECT 
    i.[IncidentId],
    i.[IncidentType],
    i.[Severity],
    i.[Priority],
    i.[Description],
    i.[Status],
    i.[EstimatedAffected],
    i.[DateReported],
    u.[FirstName] + ' ' + u.[LastName] AS [ReporterName],
    u.[Email] AS [ReporterEmail],
    l.[City],
    l.[Province],
    l.[StreetAddress],
    DATEDIFF(DAY, i.[DateReported], GETUTCDATE()) AS [DaysOpen]
FROM [Incidents] i
INNER JOIN [AspNetUsers] u ON i.[ReporterId] = u.[Id]
INNER JOIN [Locations] l ON i.[LocationId] = l.[LocationId]
WHERE i.[Status] IN ('Reported', 'In Progress', 'Investigating');
GO

-- View: Donation Summary by Donor
CREATE VIEW [dbo].[vw_DonationSummary] AS
SELECT 
    u.[Id] AS [DonorId],
    u.[FirstName] + ' ' + u.[LastName] AS [DonorName],
    u.[Email],
    COUNT(d.[DonationId]) AS [TotalDonations],
    SUM(d.[Amount]) AS [TotalAmount],
    MAX(d.[DateDonated]) AS [LastDonation]
FROM [AspNetUsers] u
INNER JOIN [Donations] d ON u.[Id] = d.[DonorId]
WHERE d.[Status] = 'Completed'
GROUP BY u.[Id], u.[FirstName], u.[LastName], u.[Email];
GO

-- View: Volunteer Performance
CREATE VIEW [dbo].[vw_VolunteerPerformance] AS
SELECT 
    v.[VolunteerId],
    u.[FirstName] + ' ' + u.[LastName] AS [VolunteerName],
    u.[Email],
    v.[Skills],
    v.[Rating],
    v.[TotalHours],
    v.[TasksCompleted],
    v.[DateRegistered],
    COUNT(vt.[VolunteerTaskId]) AS [AssignedTasks],
    AVG(CAST(vt.[Rating] AS DECIMAL(3,2))) AS [AverageTaskRating]
FROM [Volunteers] v
INNER JOIN [AspNetUsers] u ON v.[UserId] = u.[Id]
LEFT JOIN [VolunteerTasks] vt ON v.[VolunteerId] = vt.[VolunteerId]
WHERE v.[IsActive] = 1
GROUP BY v.[VolunteerId], u.[FirstName], u.[LastName], u.[Email], 
         v.[Skills], v.[Rating], v.[TotalHours], v.[TasksCompleted], v.[DateRegistered];
GO

PRINT 'Database schema created successfully!';
PRINT 'Tables created:';
PRINT '- AspNetUsers, AspNetRoles, AspNetUserRoles (Identity)';
PRINT '- Locations, Incidents, Donations, Resources';  
PRINT '- Volunteers, Tasks, VolunteerTasks';
PRINT '- Views: vw_ActiveIncidents, vw_DonationSummary, vw_VolunteerPerformance';
GO
