using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using givers.Data;
using givers.Models;
using givers.ViewModels;
using givers.Services;

namespace givers.Controllers
{
    [Authorize]
    public class IncidentsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IIncidentService _incidentService;
        private readonly ILocationService _locationService;
        private readonly ILogger<IncidentsController> _logger;

        public IncidentsController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IIncidentService incidentService,
            ILocationService locationService,
            ILogger<IncidentsController> logger)
        {
            _context = context;
            _userManager = userManager;
            _incidentService = incidentService;
            _locationService = locationService;
            _logger = logger;
        }

        // GET: Incidents
        public async Task<IActionResult> Index(string? status, string? search)
        {
            var incidents = await _incidentService.GetAllIncidentsAsync();

            // Filter by status if provided
            if (!string.IsNullOrEmpty(status) && status != "All")
            {
                incidents = incidents.Where(i => i.Status == status);
            }

            // Search functionality
            if (!string.IsNullOrEmpty(search))
            {
                incidents = incidents.Where(i => 
                    i.IncidentType.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    i.Description.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    i.Location.City.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            ViewBag.StatusList = new SelectList(new[]
            {
                new { Value = "All", Text = "All Statuses" },
                new { Value = "Reported", Text = "Reported" },
                new { Value = "In Progress", Text = "In Progress" },
                new { Value = "Resolved", Text = "Resolved" },
                new { Value = "Closed", Text = "Closed" }
            }, "Value", "Text", status ?? "All");

            ViewBag.CurrentStatus = status;
            ViewBag.CurrentSearch = search;

            return View(incidents.ToList());
        }

        // GET: Incidents/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var incident = await _incidentService.GetIncidentByIdAsync(id.Value);
            if (incident == null)
            {
                return NotFound();
            }

            return View(incident);
        }

        // GET: Incidents/Create
        public IActionResult Create()
        {
            ViewBag.IncidentTypes = GetIncidentTypes();
            ViewBag.Provinces = GetProvinces();
            return View();
        }

        // POST: Incidents/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(IncidentViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = await _userManager.GetUserAsync(User);
                    if (user == null)
                    {
                        return Challenge();
                    }

                    // Create location first
                    var location = new Location
                    {
                        StreetAddress = model.StreetAddress,
                        City = model.City,
                        Province = model.Province,
                        PostalCode = model.PostalCode,
                        Latitude = model.Latitude,
                        Longitude = model.Longitude,
                        LocationType = "Incident Location"
                    };

                    // Try to geocode if coordinates not provided
                    if (model.Latitude == null || model.Longitude == null)
                    {
                        var address = $"{model.StreetAddress}, {model.City}, {model.Province}";
                        var (lat, lng) = await _locationService.GeocodeAddressAsync(address);
                        location.Latitude = lat;
                        location.Longitude = lng;
                    }

                    location = await _locationService.CreateLocationAsync(location);

                    // Create incident
                    var incident = new Incident
                    {
                        IncidentType = model.IncidentType,
                        Severity = model.Severity,
                        Description = model.Description,
                        Priority = model.Priority,
                        EstimatedAffected = model.EstimatedAffected,
                        ReporterId = user.Id,
                        LocationId = location.LocationId,
                        Status = "Reported"
                    };

                    await _incidentService.CreateIncidentAsync(incident);

                    TempData["SuccessMessage"] = "Incident reported successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating incident");
                    ModelState.AddModelError("", "An error occurred while creating the incident. Please try again.");
                }
            }

            ViewBag.IncidentTypes = GetIncidentTypes();
            ViewBag.Provinces = GetProvinces();
            return View(model);
        }

        // GET: Incidents/Edit/5
        [Authorize(Roles = "Admin,Coordinator")]
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var incident = await _incidentService.GetIncidentByIdAsync(id.Value);
            if (incident == null)
            {
                return NotFound();
            }

            var model = new IncidentViewModel
            {
                IncidentId = incident.IncidentId,
                IncidentType = incident.IncidentType,
                Severity = incident.Severity,
                Description = incident.Description,
                Priority = incident.Priority,
                EstimatedAffected = incident.EstimatedAffected,
                Status = incident.Status,
                StreetAddress = incident.Location.StreetAddress,
                City = incident.Location.City,
                Province = incident.Location.Province,
                PostalCode = incident.Location.PostalCode,
                Latitude = incident.Location.Latitude,
                Longitude = incident.Location.Longitude
            };

            ViewBag.IncidentTypes = GetIncidentTypes();
            ViewBag.Provinces = GetProvinces();
            ViewBag.StatusList = GetStatusList();

            return View(model);
        }

        // POST: Incidents/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Coordinator")]
        public async Task<IActionResult> Edit(Guid id, IncidentViewModel model)
        {
            if (id != model.IncidentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var incident = await _incidentService.GetIncidentByIdAsync(id);
                    if (incident == null)
                    {
                        return NotFound();
                    }

                    // Update incident properties
                    incident.IncidentType = model.IncidentType;
                    incident.Severity = model.Severity;
                    incident.Description = model.Description;
                    incident.Priority = model.Priority;
                    incident.EstimatedAffected = model.EstimatedAffected;
                    incident.Status = model.Status;

                    if (model.Status == "Resolved" && incident.DateResolved == null)
                    {
                        incident.DateResolved = DateTime.UtcNow;
                    }

                    // Update location
                    incident.Location.StreetAddress = model.StreetAddress;
                    incident.Location.City = model.City;
                    incident.Location.Province = model.Province;
                    incident.Location.PostalCode = model.PostalCode;
                    incident.Location.Latitude = model.Latitude;
                    incident.Location.Longitude = model.Longitude;

                    await _incidentService.UpdateIncidentAsync(incident);

                    TempData["SuccessMessage"] = "Incident updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating incident");
                    ModelState.AddModelError("", "An error occurred while updating the incident. Please try again.");
                }
            }

            ViewBag.IncidentTypes = GetIncidentTypes();
            ViewBag.Provinces = GetProvinces();
            ViewBag.StatusList = GetStatusList();

            return View(model);
        }

        private SelectList GetIncidentTypes()
        {
            var types = new[]
            {
                "Natural Disaster",
                "Fire",
                "Flood",
                "Earthquake",
                "Storm",
                "Drought",
                "Humanitarian Crisis",
                "Medical Emergency",
                "Infrastructure Failure",
                "Other"
            };
            return new SelectList(types);
        }

        private SelectList GetProvinces()
        {
            var provinces = new[]
            {
                "Eastern Cape",
                "Free State",
                "Gauteng",
                "KwaZulu-Natal",
                "Limpopo",
                "Mpumalanga",
                "Northern Cape",
                "North West",
                "Western Cape"
            };
            return new SelectList(provinces);
        }

        private SelectList GetStatusList()
        {
            var statuses = new[]
            {
                "Reported",
                "In Progress",
                "Resolved",
                "Closed"
            };
            return new SelectList(statuses);
        }
    }
}
