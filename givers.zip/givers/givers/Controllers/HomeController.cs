using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using givers.Models;
using givers.ViewModels;
using givers.Data;
using givers.Services;
using System.Diagnostics;

namespace givers.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IDonationService _donationService;

        public HomeController(
            ILogger<HomeController> logger,
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IDonationService donationService)
        {
            _logger = logger;
            _context = context;
            _userManager = userManager;
            _donationService = donationService;
        }

        public async Task<IActionResult> Index()
        {
            var model = new DashboardViewModel();

            try
            {
                // Get dashboard statistics
                model.TotalIncidents = await _context.Incidents.CountAsync();
                model.ActiveIncidents = await _context.Incidents.CountAsync(i => i.Status == "Reported" || i.Status == "In Progress");
                model.TotalVolunteers = await _context.Volunteers.CountAsync(v => v.IsActive);
                model.TotalDonations = await _donationService.GetTotalDonationsAsync();

                // Get recent incidents
                model.RecentIncidents = await _context.Incidents
                    .Include(i => i.Location)
                    .Include(i => i.Reporter)
                    .OrderByDescending(i => i.DateReported)
                    .Take(5)
                    .ToListAsync();

                // Get recent donations (public info only)
                model.RecentDonations = await _context.Donations
                    .Where(d => !d.IsAnonymous && d.Status == "Completed")
                    .Include(d => d.Donor)
                    .OrderByDescending(d => d.DateDonated)
                    .Take(5)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error loading dashboard data");
                // Continue with empty model if database is not ready
            }

            return View(model);
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new givers.ViewModels.ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}