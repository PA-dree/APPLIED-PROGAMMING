using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using givers.Models;
using givers.ViewModels;
using givers.Services;

namespace givers.Controllers
{
    [Authorize]
    public class DonationsController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IDonationService _donationService;
        private readonly ILogger<DonationsController> _logger;

        public DonationsController(
            UserManager<ApplicationUser> userManager,
            IDonationService donationService,
            ILogger<DonationsController> logger)
        {
            _userManager = userManager;
            _donationService = donationService;
            _logger = logger;
        }

        // GET: Donations
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var donations = await _donationService.GetDonationsByUserAsync(user.Id);
            return View(donations);
        }

        // GET: Donations/Create
        public IActionResult Create()
        {
            var model = new DonationViewModel
            {
                Resources = new List<ResourceViewModel>()
            };

            ViewBag.DonationTypes = GetDonationTypes();
            ViewBag.PaymentMethods = GetPaymentMethods();
            ViewBag.ResourceTypes = GetResourceTypes();
            ViewBag.Units = GetUnits();

            return View(model);
        }

        // POST: Donations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DonationViewModel model)
        {
            // Ignore resource validation unless this is a Material donation
            if (!string.Equals(model.DonationType, "Material", StringComparison.OrdinalIgnoreCase))
            {
                model.Resources = null;
                foreach (var key in ModelState.Keys.Where(k => k.StartsWith("Resources")))
                {
                    ModelState.Remove(key);
                }
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var user = await _userManager.GetUserAsync(User);
                    if (user == null)
                    {
                        return Challenge();
                    }

                    var donation = new Donation
                    {
                        Amount = model.Amount,
                        DonationType = model.DonationType,
                        PaymentMethod = model.PaymentMethod,
                        IsAnonymous = model.IsAnonymous,
                        DonorId = user.Id,
                        Status = "Pending"
                    };

                    // Add resources for material donations
                    if (model.DonationType == "Material" && model.Resources != null)
                    {
                        foreach (var resourceViewModel in model.Resources.Where(r => !string.IsNullOrWhiteSpace(r.ResourceType)))
                        {
                            var resource = new Resource
                            {
                                ResourceType = resourceViewModel.ResourceType,
                                Quantity = resourceViewModel.Quantity,
                                Unit = resourceViewModel.Unit,
                                Description = resourceViewModel.Description,
                                EstimatedValue = resourceViewModel.EstimatedValue,
                                StorageLocation = resourceViewModel.StorageLocation
                            };
                            donation.Resources.Add(resource);
                        }
                    }

                    // Create the donation
                    await _donationService.CreateDonationAsync(donation);

                    // Process payment for monetary donations
                    if (model.DonationType == "Monetary")
                    {
                        var paymentResult = await _donationService.ProcessPaymentAsync(donation);
                        if (paymentResult == "Success")
                        {
                            TempData["SuccessMessage"] = "Thank you for your donation! Payment processed successfully.";
                        }
                        else
                        {
                            TempData["ErrorMessage"] = "Payment processing failed. Please try again.";
                        }
                    }
                    else
                    {
                        TempData["SuccessMessage"] = "Thank you for your donation! We will contact you regarding pickup/delivery arrangements.";
                    }

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error creating donation");
                    ModelState.AddModelError("", "An error occurred while processing your donation. Please try again.");
                }
            }

            ViewBag.DonationTypes = GetDonationTypes();
            ViewBag.PaymentMethods = GetPaymentMethods();
            ViewBag.ResourceTypes = GetResourceTypes();
            ViewBag.Units = GetUnits();

            return View(model);
        }

        // GET: Donations/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var donations = await _donationService.GetDonationsByUserAsync(user.Id);
            var donation = donations.FirstOrDefault(d => d.DonationId == id.Value);

            if (donation == null)
            {
                return NotFound();
            }

            return View(donation);
        }

        // GET: Donations/Receipt/5
        public async Task<IActionResult> Receipt(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var donations = await _donationService.GetDonationsByUserAsync(user.Id);
            var donation = donations.FirstOrDefault(d => d.DonationId == id.Value);

            if (donation == null)
            {
                return NotFound();
            }

            try
            {
                var receiptPdf = await _donationService.GenerateReceiptPdfAsync(id.Value);
                if (receiptPdf != null)
                {
                    return File(receiptPdf, "application/pdf", $"Receipt_{donation.ReceiptNumber}.pdf");
                }
                else
                {
                    TempData["ErrorMessage"] = "Unable to generate receipt. Please contact support.";
                    return RedirectToAction("Details", new { id });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating receipt for donation {DonationId}", id);
                TempData["ErrorMessage"] = "An error occurred while generating the receipt.";
                return RedirectToAction("Details", new { id });
            }
        }

        [HttpPost]
        public IActionResult AddResource(DonationViewModel model)
        {
            model.Resources ??= new List<ResourceViewModel>();
            model.Resources.Add(new ResourceViewModel());

            ViewBag.DonationTypes = GetDonationTypes();
            ViewBag.PaymentMethods = GetPaymentMethods();
            ViewBag.ResourceTypes = GetResourceTypes();
            ViewBag.Units = GetUnits();

            return View("Create", model);
        }

        [HttpPost]
        public IActionResult RemoveResource(DonationViewModel model, int index)
        {
            if (model.Resources != null && index >= 0 && index < model.Resources.Count)
            {
                model.Resources.RemoveAt(index);
            }

            ViewBag.DonationTypes = GetDonationTypes();
            ViewBag.PaymentMethods = GetPaymentMethods();
            ViewBag.ResourceTypes = GetResourceTypes();
            ViewBag.Units = GetUnits();

            return View("Create", model);
        }

        private SelectList GetDonationTypes()
        {
            var types = new[]
            {
                new { Value = "Monetary", Text = "Monetary Donation" },
                new { Value = "Material", Text = "Material Donation" },
                new { Value = "Service", Text = "Service Donation" }
            };
            return new SelectList(types, "Value", "Text");
        }

        private SelectList GetPaymentMethods()
        {
            var methods = new[]
            {
                new { Value = "Credit Card", Text = "Credit Card" },
                new { Value = "Debit Card", Text = "Debit Card" },
                new { Value = "Bank Transfer", Text = "Bank Transfer" },
                new { Value = "PayPal", Text = "PayPal" },
                new { Value = "Cash", Text = "Cash" }
            };
            return new SelectList(methods, "Value", "Text");
        }

        private SelectList GetResourceTypes()
        {
            var types = new[]
            {
                "Food - Non-perishable",
                "Food - Fresh produce",
                "Clothing - Adult",
                "Clothing - Children",
                "Medical supplies",
                "Blankets and bedding",
                "Water and beverages",
                "Personal hygiene items",
                "Baby supplies",
                "Household items",
                "Tools and equipment",
                "Books and educational materials",
                "Toys and games",
                "Electronics",
                "Other"
            };
            return new SelectList(types);
        }

        private SelectList GetUnits()
        {
            var units = new[]
            {
                "pieces",
                "kg",
                "liters",
                "boxes",
                "bags",
                "packs",
                "sets",
                "pairs",
                "bottles",
                "cans"
            };
            return new SelectList(units);
        }
    }
}
