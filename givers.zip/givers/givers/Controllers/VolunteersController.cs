using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using givers.Data;
using givers.Models;
using givers.ViewModels;
using givers.Services;

namespace givers.Controllers
{
    [Authorize]
    public class VolunteersController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IVolunteerService _volunteerService;
        private readonly ILogger<VolunteersController> _logger;

        public VolunteersController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IVolunteerService volunteerService,
            ILogger<VolunteersController> logger)
        {
            _context = context;
            _userManager = userManager;
            _volunteerService = volunteerService;
            _logger = logger;
        }

        // GET: Volunteers/Register
        public async Task<IActionResult> Register()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            // Check if user already has a volunteer profile
            var existingVolunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == user.Id);

            if (existingVolunteer != null)
            {
                TempData["InfoMessage"] = "You are already registered as a volunteer.";
                return RedirectToAction("Dashboard");
            }

            return View();
        }

        // POST: Volunteers/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(VolunteerViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = await _userManager.GetUserAsync(User);
                    if (user == null)
                    {
                        return Challenge();
                    }

                    // Check if user already has a volunteer profile
                    var existingVolunteer = await _context.Volunteers
                        .FirstOrDefaultAsync(v => v.UserId == user.Id);

                    if (existingVolunteer != null)
                    {
                        TempData["ErrorMessage"] = "You are already registered as a volunteer.";
                        return RedirectToAction("Dashboard");
                    }

                    var volunteer = new Volunteer
                    {
                        UserId = user.Id,
                        Skills = model.Skills,
                        Availability = model.Availability,
                        EmergencyContact = model.EmergencyContact,
                        PreferredTasks = model.PreferredTasks,
                        BackgroundCheckStatus = "Pending",
                        IsActive = true
                    };

                    await _volunteerService.RegisterVolunteerAsync(volunteer);

                    // Update user role if not already a volunteer
                    if (!await _userManager.IsInRoleAsync(user, "Volunteer"))
                    {
                        await _userManager.AddToRoleAsync(user, "Volunteer");
                    }

                    TempData["SuccessMessage"] = "Volunteer registration successful! Welcome to our team.";
                    return RedirectToAction("Dashboard");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error registering volunteer");
                    ModelState.AddModelError("", "An error occurred during registration. Please try again.");
                }
            }

            return View(model);
        }

        // GET: Volunteers/Dashboard
        public async Task<IActionResult> Dashboard()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var volunteer = await _context.Volunteers
                .Include(v => v.VolunteerTasks)
                    .ThenInclude(vt => vt.Task)
                        .ThenInclude(t => t.Incident)
                .FirstOrDefaultAsync(v => v.UserId == user.Id);

            if (volunteer == null)
            {
                return RedirectToAction("Register");
            }

            var availableTasks = await _volunteerService.GetAvailableTasksAsync();
            var volunteerTasks = await _volunteerService.GetVolunteerTasksAsync(volunteer.VolunteerId);

            var model = new VolunteerDashboardViewModel
            {
                Volunteer = volunteer,
                AvailableTasks = availableTasks.ToList(),
                AssignedTasks = volunteerTasks.Where(vt => vt.Status == "Assigned").ToList(),
                CompletedTasks = volunteerTasks.Where(vt => vt.Status == "Completed").ToList(),
                TotalHours = volunteer.HoursContributed,
                TasksCompleted = volunteerTasks.Count(vt => vt.Status == "Completed")
            };

            return View(model);
        }

        // GET: Volunteers/Tasks
        public async Task<IActionResult> Tasks(string? filter)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var volunteer = await _context.Volunteers
                .FirstOrDefaultAsync(v => v.UserId == user.Id);

            if (volunteer == null)
            {
                return RedirectToAction("Register");
            }

            var availableTasks = await _volunteerService.GetAvailableTasksAsync();

            // Apply filters
            if (!string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "urgent":
                        availableTasks = availableTasks.Where(t => t.Priority >= 8);
                        break;
                    case "today":
                        availableTasks = availableTasks.Where(t => t.DateDue?.Date == DateTime.Today);
                        break;
                    case "skills":
                        // Filter by volunteer's skills
                        var volunteerSkills = volunteer.Skills.Split(',', StringSplitOptions.RemoveEmptyEntries)
                            .Select(s => s.Trim().ToLower()).ToList();
                        availableTasks = availableTasks.Where(t => 
                            !string.IsNullOrEmpty(t.RequiredSkills) &&
                            volunteerSkills.Any(skill => 
                                t.RequiredSkills.ToLower().Contains(skill)));
                        break;
                }
            }

            ViewBag.CurrentFilter = filter;
            ViewBag.VolunteerId = volunteer.VolunteerId;

            return View(availableTasks.ToList());
        }

        // POST: Volunteers/AssignTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AssignTask(Guid taskId)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return Challenge();
                }

                var volunteer = await _context.Volunteers
                    .FirstOrDefaultAsync(v => v.UserId == user.Id);

                if (volunteer == null)
                {
                    TempData["ErrorMessage"] = "You must register as a volunteer first.";
                    return RedirectToAction("Register");
                }

                // Check if task is still available
                var task = await _context.Tasks.FindAsync(taskId);
                if (task == null || task.Status != "Open")
                {
                    TempData["ErrorMessage"] = "This task is no longer available.";
                    return RedirectToAction("Tasks");
                }

                // Check if volunteer is already assigned to this task
                var existingAssignment = await _context.VolunteerTasks
                    .FirstOrDefaultAsync(vt => vt.VolunteerId == volunteer.VolunteerId && vt.TaskId == taskId);

                if (existingAssignment != null)
                {
                    TempData["ErrorMessage"] = "You are already assigned to this task.";
                    return RedirectToAction("Tasks");
                }

                await _volunteerService.AssignTaskToVolunteerAsync(volunteer.VolunteerId, taskId);

                TempData["SuccessMessage"] = "Task assigned successfully!";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error assigning task {TaskId}", taskId);
                TempData["ErrorMessage"] = "An error occurred while assigning the task. Please try again.";
                return RedirectToAction("Tasks");
            }
        }

        // POST: Volunteers/CompleteTask
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CompleteTask(Guid taskId, decimal hoursWorked, string? comments)
        {
            try
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return Challenge();
                }

                var volunteer = await _context.Volunteers
                    .FirstOrDefaultAsync(v => v.UserId == user.Id);

                if (volunteer == null)
                {
                    return RedirectToAction("Register");
                }

                await _volunteerService.CompleteTaskAsync(volunteer.VolunteerId, taskId, hoursWorked);

                // Update comments if provided
                if (!string.IsNullOrEmpty(comments))
                {
                    var volunteerTask = await _context.VolunteerTasks
                        .FirstOrDefaultAsync(vt => vt.VolunteerId == volunteer.VolunteerId && vt.TaskId == taskId);
                    
                    if (volunteerTask != null)
                    {
                        volunteerTask.Comments = comments;
                        await _context.SaveChangesAsync();
                    }
                }

                TempData["SuccessMessage"] = "Task completed successfully! Thank you for your contribution.";
                return RedirectToAction("Dashboard");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error completing task {TaskId}", taskId);
                TempData["ErrorMessage"] = "An error occurred while completing the task. Please try again.";
                return RedirectToAction("Dashboard");
            }
        }

        // GET: Volunteers/Profile
        public async Task<IActionResult> Profile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Challenge();
            }

            var volunteer = await _context.Volunteers
                .Include(v => v.User)
                .FirstOrDefaultAsync(v => v.UserId == user.Id);

            if (volunteer == null)
            {
                return RedirectToAction("Register");
            }

            var model = new VolunteerViewModel
            {
                Skills = volunteer.Skills,
                Availability = volunteer.Availability,
                EmergencyContact = volunteer.EmergencyContact,
                PreferredTasks = volunteer.PreferredTasks
            };

            return View(model);
        }

        // POST: Volunteers/Profile
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Profile(VolunteerViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = await _userManager.GetUserAsync(User);
                    if (user == null)
                    {
                        return Challenge();
                    }

                    var volunteer = await _context.Volunteers
                        .FirstOrDefaultAsync(v => v.UserId == user.Id);

                    if (volunteer == null)
                    {
                        return RedirectToAction("Register");
                    }

                    volunteer.Skills = model.Skills;
                    volunteer.Availability = model.Availability;
                    volunteer.EmergencyContact = model.EmergencyContact;
                    volunteer.PreferredTasks = model.PreferredTasks;

                    _context.Update(volunteer);
                    await _context.SaveChangesAsync();

                    TempData["SuccessMessage"] = "Volunteer profile updated successfully!";
                    return RedirectToAction("Profile");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error updating volunteer profile");
                    ModelState.AddModelError("", "An error occurred while updating your profile. Please try again.");
                }
            }

            return View(model);
        }
    }
}
