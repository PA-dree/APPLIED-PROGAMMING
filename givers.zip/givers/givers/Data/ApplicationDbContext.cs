﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using givers.Models;

namespace givers.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // DbSets for all entities
        public DbSet<Incident> Incidents { get; set; }
        public DbSet<Donation> Donations { get; set; }
        public DbSet<Resource> Resources { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
        public DbSet<TaskItem> Tasks { get; set; }
        public DbSet<VolunteerTask> VolunteerTasks { get; set; }
        public DbSet<Location> Locations { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure User entity
            builder.Entity<ApplicationUser>(entity =>
            {
                entity.Property(e => e.FirstName).HasMaxLength(100).IsRequired();
                entity.Property(e => e.LastName).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Role).HasMaxLength(50);
                entity.Property(e => e.ProfileImageUrl).HasMaxLength(500);
                entity.HasIndex(e => e.Email).IsUnique();
            });

            // Configure Incident entity
            builder.Entity<Incident>(entity =>
            {
                entity.HasKey(e => e.IncidentId);
                entity.Property(e => e.IncidentType).HasMaxLength(50).IsRequired();
                entity.Property(e => e.Description).IsRequired();
                entity.Property(e => e.Status).HasMaxLength(50).HasDefaultValue("Reported");

                entity.HasOne(e => e.Reporter)
                    .WithMany(u => u.ReportedIncidents)
                    .HasForeignKey(e => e.ReporterId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Location)
                    .WithMany(l => l.Incidents)
                    .HasForeignKey(e => e.LocationId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.ToTable(t =>
                {
                    t.HasCheckConstraint("CK_Incident_Severity", "Severity BETWEEN 1 AND 5");
                    t.HasCheckConstraint("CK_Incident_Priority", "Priority BETWEEN 1 AND 10");
                });
            });

            // Configure Donation entity
            builder.Entity<Donation>(entity =>
            {
                entity.HasKey(e => e.DonationId);
                entity.Property(e => e.Amount).HasPrecision(10, 2);
                entity.Property(e => e.Currency).HasMaxLength(3).HasDefaultValue("ZAR");
                entity.Property(e => e.DonationType).HasMaxLength(50);
                entity.Property(e => e.PaymentMethod).HasMaxLength(50);
                entity.Property(e => e.TransactionReference).HasMaxLength(100);
                entity.Property(e => e.ReceiptNumber).HasMaxLength(50);
                entity.Property(e => e.Status).HasMaxLength(50).HasDefaultValue("Pending");

                entity.HasOne(e => e.Donor)
                    .WithMany(u => u.Donations)
                    .HasForeignKey(e => e.DonorId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasIndex(e => e.TransactionReference).IsUnique();
                entity.HasIndex(e => e.ReceiptNumber).IsUnique();
                entity.ToTable(t =>
                {
                    t.HasCheckConstraint("CK_Donation_Type",
                        "DonationType IN ('Monetary','Material','Service')");
                });
            });

            // Configure Resource entity
            builder.Entity<Resource>(entity =>
            {
                entity.HasKey(e => e.ResourceId);
                entity.Property(e => e.ResourceType).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Unit).HasMaxLength(20);
                entity.Property(e => e.Description).HasMaxLength(500);
                entity.Property(e => e.EstimatedValue).HasPrecision(10, 2);
                entity.Property(e => e.StorageLocation).HasMaxLength(200);
                entity.Property(e => e.Status).HasMaxLength(50).HasDefaultValue("Available");

                entity.HasOne(e => e.Donation)
                    .WithMany(d => d.Resources)
                    .HasForeignKey(e => e.DonationId)
                    .OnDelete(DeleteBehavior.SetNull);

                entity.ToTable(t =>
                {
                    t.HasCheckConstraint("CK_Resource_Quantity", "Quantity > 0");
                });
            });

            // Configure Volunteer entity
            builder.Entity<Volunteer>(entity =>
            {
                entity.HasKey(e => e.VolunteerId);
                entity.Property(e => e.EmergencyContact).HasMaxLength(200);
                entity.Property(e => e.BackgroundCheckStatus).HasMaxLength(50);
                entity.Property(e => e.HoursContributed).HasPrecision(10, 2).HasDefaultValue(0);
                entity.Property(e => e.Rating).HasPrecision(3, 2);
                entity.Property(e => e.IsActive).HasDefaultValue(true);

                entity.HasOne(e => e.User)
                    .WithOne(u => u.VolunteerProfile)
                    .HasForeignKey<Volunteer>(e => e.UserId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(e => e.UserId).IsUnique();
                entity.ToTable(t =>
                {
                    t.HasCheckConstraint("CK_Volunteer_Rating", "Rating BETWEEN 0 AND 5");
                });
            });

            // Configure Task entity
            builder.Entity<TaskItem>(entity =>
            {
                entity.HasKey(e => e.TaskId);
                entity.Property(e => e.Title).HasMaxLength(200).IsRequired();
                entity.Property(e => e.RequiredSkills).HasMaxLength(500);
                entity.Property(e => e.EstimatedHours).HasPrecision(5, 2);
                entity.Property(e => e.Status).HasMaxLength(50).HasDefaultValue("Open");
                entity.Property(e => e.MaxVolunteers).HasDefaultValue(1);

                entity.HasOne(e => e.Incident)
                    .WithMany(i => i.Tasks)
                    .HasForeignKey(e => e.IncidentId)
                    .OnDelete(DeleteBehavior.SetNull);

                entity.ToTable(t =>
                {
                    t.HasCheckConstraint("CK_Task_Priority", "Priority BETWEEN 1 AND 10");
                });
            });

            // Configure VolunteerTask entity (many-to-many)
            builder.Entity<VolunteerTask>(entity =>
            {
                entity.HasKey(e => new { e.VolunteerId, e.TaskId });

                entity.Property(e => e.Status).HasMaxLength(50).HasDefaultValue("Assigned");
                entity.Property(e => e.HoursWorked).HasPrecision(5, 2);
                entity.Property(e => e.Comments).HasMaxLength(500);

                entity.HasOne(e => e.Volunteer)
                    .WithMany(v => v.VolunteerTasks)
                    .HasForeignKey(e => e.VolunteerId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Task)
                    .WithMany(t => t.VolunteerTasks)
                    .HasForeignKey(e => e.TaskId)
                    .OnDelete(DeleteBehavior.Restrict);

                entity.ToTable(t =>
                {
                    t.HasCheckConstraint("CK_VolunteerTask_Rating", "Rating BETWEEN 1 AND 5");
                });
            });

            // Configure Location entity
            builder.Entity<Location>(entity =>
            {
                entity.HasKey(e => e.LocationId);
                entity.Property(e => e.StreetAddress).HasMaxLength(200);
                entity.Property(e => e.City).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Province).HasMaxLength(100).IsRequired();
                entity.Property(e => e.PostalCode).HasMaxLength(10);
                entity.Property(e => e.Country).HasMaxLength(100).HasDefaultValue("South Africa");
                entity.Property(e => e.Latitude).HasPrecision(10, 8);
                entity.Property(e => e.Longitude).HasPrecision(11, 8);
                entity.Property(e => e.LocationType).HasMaxLength(50);
            });
        }
    }
}