using Microsoft.AspNetCore.Identity;
using givers.Models;

namespace givers.Data
{
    public static class SeedData
    {
        public static async Task Initialize(IServiceProvider serviceProvider, UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            // Seed roles
            await SeedRoles(roleManager);

            // Seed admin user
            await SeedAdminUser(userManager);

            // Seed sample data
            var context = serviceProvider.GetRequiredService<ApplicationDbContext>();
            await SeedSampleData(context);
        }

        private static async Task SeedRoles(RoleManager<IdentityRole> roleManager)
        {
            string[] roleNames = { "Admin", "User", "Volunteer", "Coordinator" };

            foreach (var roleName in roleNames)
            {
                if (!await roleManager.RoleExistsAsync(roleName))
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }
        }

        private static async Task SeedAdminUser(UserManager<ApplicationUser> userManager)
        {
            var adminEmail = "admin@disasteralleviation.org";
            var adminUser = await userManager.FindByEmailAsync(adminEmail);

            if (adminUser == null)
            {
                adminUser = new ApplicationUser
                {
                    UserName = adminEmail,
                    Email = adminEmail,
                    FirstName = "System",
                    LastName = "Administrator",
                    Role = "Admin",
                    EmailConfirmed = true,
                    IsActive = true
                };

                var result = await userManager.CreateAsync(adminUser, "Admin123!");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(adminUser, "Admin");
                }
            }
        }

        private static async Task SeedSampleData(ApplicationDbContext context)
        {
            // Add sample locations if none exist
            if (!context.Locations.Any())
            {
                var locations = new List<Location>
                {
                    new Location
                    {
                        City = "Cape Town",
                        Province = "Western Cape",
                        Country = "South Africa",
                        LocationType = "Distribution Center",
                        Latitude = -33.9249m,
                        Longitude = 18.4241m
                    },
                    new Location
                    {
                        City = "Johannesburg",
                        Province = "Gauteng",
                        Country = "South Africa",
                        LocationType = "Emergency Shelter",
                        Latitude = -26.2041m,
                        Longitude = 28.0473m
                    },
                    new Location
                    {
                        City = "Durban",
                        Province = "KwaZulu-Natal",
                        Country = "South Africa",
                        LocationType = "Distribution Center",
                        Latitude = -29.8587m,
                        Longitude = 31.0218m
                    }
                };

                context.Locations.AddRange(locations);
                await context.SaveChangesAsync();
            }
        }
    }
}
